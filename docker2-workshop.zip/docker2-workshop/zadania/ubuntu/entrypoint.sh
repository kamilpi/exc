#!/bin/bash

i=0

until [ $i -gt 10000000 ]
do
  echo i: $i
  ((i=i+1))
  sleep 4
done
