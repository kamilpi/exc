#!/bin/bash

ls -la /pliki/
sleep 5